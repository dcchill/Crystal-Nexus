package net.crystalnexus.block;

import io.netty.buffer.Unpooled;
import net.crystalnexus.block.entity.RefineryBlockEntity;
import net.crystalnexus.procedures.RefineryOnTickUpdateProcedure;
import net.crystalnexus.processing.MachineTier;
import net.crystalnexus.processing.TieredMachineBlock;
import net.crystalnexus.world.inventory.RefineryMenu;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

public final class RefineryBlock extends ChemicalReactionChamberBlock implements TieredMachineBlock {
    private final MachineTier machineTier;
    public RefineryBlock() { this(MachineTier.CRYSTAL); }
    public RefineryBlock(MachineTier machineTier) { this.machineTier = machineTier; }
    @Override public MachineTier machineTier() { return machineTier; }
    @Override public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        RefineryOnTickUpdateProcedure.execute(level, pos);
        level.scheduleTick(pos, this, 1);
    }
    @Override public InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (player instanceof ServerPlayer serverPlayer) serverPlayer.openMenu(new MenuProvider() {
            @Override public Component getDisplayName() { return Component.literal(machineTier.displayName() + " Refinery"); }
            @Override public AbstractContainerMenu createMenu(int id, Inventory inventory, Player ignored) {
                return new RefineryMenu(id, inventory, new FriendlyByteBuf(Unpooled.buffer()).writeBlockPos(pos));
            }
        }, pos);
        return InteractionResult.SUCCESS;
    }
    @Override public BlockEntity newBlockEntity(BlockPos pos, BlockState state) { return new RefineryBlockEntity(pos, state); }
    @Override public void onRemove(BlockState state, Level level, BlockPos pos, BlockState next, boolean moving) {
        if (state.getBlock() != next.getBlock()) {
            if (level.getBlockEntity(pos) instanceof RefineryBlockEntity refinery) Containers.dropContents(level, pos, refinery);
            super.onRemove(state, level, pos, next, moving);
        }
    }
}
